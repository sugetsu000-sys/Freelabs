# FreeLabs 🎙️

**Aplikasi Text-to-Speech gratis berkualitas tinggi** — alternatif ElevenLabs yang fully free.

Powered by **Microsoft Edge Neural TTS** (300+ suara natural, multi bahasa).

## Fitur

- Text-to-Speech berkualitas tinggi (Neural Voices)
- 300+ suara dari berbagai bahasa (termasuk Bahasa Indonesia)
- Kontrol Speed, Pitch, dan Volume
- Play / Pause langsung di aplikasi
- Download hasil sebagai file MP3
- Riwayat generasi
- UI modern gelap (mirip ElevenLabs)
- 100% gratis, tanpa API key

---

## Cara Dapat APK (Paling Mudah)

### Menggunakan GitHub Actions (Recommended)

1. **Buat repository baru** di GitHub (bisa private)
2. **Upload semua file** project ini ke repository tersebut
3. Tunggu beberapa menit sampai workflow selesai berjalan
4. Buka tab **Actions** → pilih workflow yang sukses → download artifact **freelabs-apk**
5. Extract file zip → dapatkan `app-release.apk`
6. Install di HP Android

> Workflow akan otomatis berjalan setiap kali kamu push ke branch `main` atau `master`.  
> Kamu juga bisa klik **Run workflow** secara manual di tab Actions.

---

## Cara Build Manual (di komputer)

```bash
# 1. Pastikan Flutter sudah terinstall
flutter doctor

# 2. Masuk ke folder project
cd freelabs

# 3. Generate folder android/ios (hanya sekali)
flutter create . --project-name freelabs --org com.freelabs.app

# 4. Install dependencies
flutter pub get

# 5. Build APK
flutter build apk --release
```

APK akan berada di:
```
build/app/outputs/flutter-apk/app-release.apk
```

---

## Struktur Project

```
freelabs/
├── .github/
│   └── workflows/
│       └── build-apk.yml      ← GitHub Actions
├── lib/
│   ├── main.dart
│   ├── models/
│   ├── screens/
│   ├── services/
│   ├── utils/
│   └── widgets/
├── assets/
├── pubspec.yaml
└── README.md
```

---

## Catatan

- Menggunakan package `edge_tts` (Microsoft Edge Neural TTS)
- Tidak memerlukan API key
- Audio dihasilkan dalam format MP3
- History disimpan lokal
- **Voice Cloning** belum tersedia di versi ini (butuh model besar / server)

---

## Lisensi

MIT — silakan pakai, modifikasi, dan distribusikan bebas.
