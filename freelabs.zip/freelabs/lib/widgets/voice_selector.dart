import 'package:edge_tts/edge_tts.dart';
import 'package:flutter/material.dart';
import '../services/tts_service.dart';
import '../utils/app_theme.dart';

class VoiceSelector extends StatelessWidget {
  final List<Voice> voices;
  final Voice? selectedVoice;
  final String? selectedLocale;
  final ValueChanged<String> onLocaleChanged;
  final ValueChanged<Voice> onVoiceChanged;

  const VoiceSelector({
    super.key,
    required this.voices,
    required this.selectedVoice,
    required this.selectedLocale,
    required this.onLocaleChanged,
    required this.onVoiceChanged,
  });

  @override
  Widget build(BuildContext context) {
    final locales = voices.map((v) => v.locale).toSet().toList()..sort();
    final localeVoices = selectedLocale != null
        ? voices.where((v) => v.locale == selectedLocale).toList()
        : <Voice>[];

    return Column(
      children: [
        // Locale dropdown
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          decoration: BoxDecoration(
            color: AppTheme.surfaceElevated,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.border),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: selectedLocale,
              isExpanded: true,
              dropdownColor: AppTheme.surfaceElevated,
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppTheme.textSecondary),
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
              items: locales.map((locale) {
                final count = voices.where((v) => v.locale == locale).length;
                return DropdownMenuItem(
                  value: locale,
                  child: Text('$locale  ($count suara)'),
                );
              }).toList(),
              onChanged: (value) {
                if (value != null) onLocaleChanged(value);
              },
            ),
          ),
        ),
        const SizedBox(height: 10),

        // Voice dropdown
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          decoration: BoxDecoration(
            color: AppTheme.surfaceElevated,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.border),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<Voice>(
              value: selectedVoice,
              isExpanded: true,
              dropdownColor: AppTheme.surfaceElevated,
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppTheme.textSecondary),
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
              items: localeVoices.map((voice) {
                final name = TtsService.getDisplayName(voice);
                final gender = TtsService.getGenderIcon(voice.gender);
                return DropdownMenuItem(
                  value: voice,
                  child: Row(
                    children: [
                      Text(gender, style: const TextStyle(fontSize: 16)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          name,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (voice.shortName.contains('Multilingual'))
                        Container(
                          margin: const EdgeInsets.only(left: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.primary.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'Multi',
                            style: TextStyle(
                              fontSize: 10,
                              color: AppTheme.primaryLight,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              }).toList(),
              onChanged: (value) {
                if (value != null) onVoiceChanged(value);
              },
            ),
          ),
        ),
      ],
    );
  }
}
