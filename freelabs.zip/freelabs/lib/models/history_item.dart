class HistoryItem {
  final String id;
  final String text;
  final String voice;
  final String voiceDisplayName;
  final String locale;
  final DateTime createdAt;
  final String? filePath;

  HistoryItem({
    required this.id,
    required this.text,
    required this.voice,
    required this.voiceDisplayName,
    required this.locale,
    required this.createdAt,
    this.filePath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'voice': voice,
        'voiceDisplayName': voiceDisplayName,
        'locale': locale,
        'createdAt': createdAt.toIso8601String(),
        'filePath': filePath,
      };

  factory HistoryItem.fromJson(Map<String, dynamic> json) => HistoryItem(
        id: json['id'],
        text: json['text'],
        voice: json['voice'],
        voiceDisplayName: json['voiceDisplayName'],
        locale: json['locale'],
        createdAt: DateTime.parse(json['createdAt']),
        filePath: json['filePath'],
      );

  String get previewText {
    if (text.length <= 80) return text;
    return '${text.substring(0, 80)}...';
  }
}
