import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/history_item.dart';
import '../services/history_service.dart';
import '../utils/app_theme.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final HistoryService _historyService = HistoryService();
  final AudioPlayer _player = AudioPlayer();
  List<HistoryItem> _items = [];
  bool _loading = true;
  String? _playingId;

  @override
  void initState() {
    super.initState();
    _load();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playingId = null);
    });
  }

  Future<void> _load() async {
    final items = await _historyService.getHistory();
    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
    });
  }

  Future<void> _play(HistoryItem item) async {
    if (item.filePath == null) return;
    try {
      if (_playingId == item.id) {
        await _player.stop();
        setState(() => _playingId = null);
      } else {
        await _player.stop();
        await _player.play(DeviceFileSource(item.filePath!));
        setState(() => _playingId = item.id);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memutar: $e'), backgroundColor: AppTheme.danger),
      );
    }
  }

  Future<void> _delete(HistoryItem item) async {
    await _historyService.removeItem(item.id);
    await _load();
  }

  Future<void> _clearAll() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Hapus Semua Riwayat?'),
        content: const Text('Tindakan ini tidak dapat dibatalkan.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus', style: TextStyle(color: AppTheme.danger)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await _historyService.clearAll();
      await _load();
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat'),
        actions: [
          if (_items.isNotEmpty)
            IconButton(
              onPressed: _clearAll,
              icon: const Icon(Icons.delete_sweep_rounded),
              tooltip: 'Hapus semua',
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
          : _items.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.history_rounded, size: 64, color: AppTheme.textMuted.withOpacity(0.5)),
                      const SizedBox(height: 16),
                      const Text(
                        'Belum ada riwayat',
                        style: TextStyle(color: AppTheme.textSecondary, fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Generate speech untuk mulai menyimpan',
                        style: TextStyle(color: AppTheme.textMuted, fontSize: 13),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final item = _items[index];
                    final isPlaying = _playingId == item.id;
                    final dateStr = DateFormat('dd MMM yyyy • HH:mm').format(item.createdAt);

                    return Container(
                      decoration: BoxDecoration(
                        color: AppTheme.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppTheme.border),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        leading: Material(
                          color: isPlaying ? AppTheme.primary : AppTheme.surfaceElevated,
                          borderRadius: BorderRadius.circular(50),
                          child: InkWell(
                            onTap: () => _play(item),
                            borderRadius: BorderRadius.circular(50),
                            child: SizedBox(
                              width: 42,
                              height: 42,
                              child: Icon(
                                isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                color: isPlaying ? Colors.white : AppTheme.textPrimary,
                                size: 24,
                              ),
                            ),
                          ),
                        ),
                        title: Text(
                          item.previewText,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 14, height: 1.3),
                        ),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            '${item.voiceDisplayName} • ${item.locale} • $dateStr',
                            style: const TextStyle(fontSize: 12, color: AppTheme.textMuted),
                          ),
                        ),
                        trailing: IconButton(
                          onPressed: () => _delete(item),
                          icon: const Icon(Icons.delete_outline_rounded, size: 20),
                          color: AppTheme.textMuted,
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
