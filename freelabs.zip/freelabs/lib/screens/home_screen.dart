import 'dart:io';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:edge_tts/edge_tts.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import '../models/history_item.dart';
import '../services/history_service.dart';
import '../services/tts_service.dart';
import '../utils/app_theme.dart';
import '../widgets/voice_selector.dart';
import 'history_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _textController = TextEditingController();
  final TtsService _ttsService = TtsService();
  final HistoryService _historyService = HistoryService();
  final AudioPlayer _audioPlayer = AudioPlayer();

  List<Voice> _voices = [];
  Voice? _selectedVoice;
  String? _selectedLocale;

  bool _isLoadingVoices = true;
  bool _isGenerating = false;
  bool _isPlaying = false;

  // Prosody controls
  double _rate = 0; // -50 to +50 → mapped to %
  double _pitch = 0; // -20 to +20 → mapped to Hz
  double _volume = 0; // -50 to +50 → mapped to %

  Uint8List? _currentAudio;
  String? _currentFilePath;

  @override
  void initState() {
    super.initState();
    _loadVoices();
    _audioPlayer.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _isPlaying = false);
    });
  }

  Future<void> _loadVoices() async {
    try {
      final voices = await _ttsService.loadVoices();
      if (!mounted) return;
      setState(() {
        _voices = voices;
        _isLoadingVoices = false;

        // Default: Indonesian or English
        final idVoices = voices.where((v) => v.locale.startsWith('id')).toList();
        final enVoices = voices.where((v) => v.locale.startsWith('en')).toList();

        if (idVoices.isNotEmpty) {
          _selectedLocale = idVoices.first.locale;
          _selectedVoice = idVoices.first;
        } else if (enVoices.isNotEmpty) {
          _selectedLocale = 'en-US';
          _selectedVoice = enVoices.firstWhere(
            (v) => v.shortName.contains('Aria') || v.shortName.contains('Jenny'),
            orElse: () => enVoices.first,
          );
        } else if (voices.isNotEmpty) {
          _selectedLocale = voices.first.locale;
          _selectedVoice = voices.first;
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoadingVoices = false);
      _showError('Gagal memuat daftar suara: $e');
    }
  }

  String get _rateStr {
    final value = _rate.round();
    return value >= 0 ? '+$value%' : '$value%';
  }

  String get _pitchStr {
    final value = _pitch.round();
    return value >= 0 ? '+${value}Hz' : '${value}Hz';
  }

  String get _volumeStr {
    final value = _volume.round();
    return value >= 0 ? '+$value%' : '$value%';
  }

  Future<void> _generate() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      _showError('Masukkan teks terlebih dahulu');
      return;
    }
    if (_selectedVoice == null) {
      _showError('Pilih suara terlebih dahulu');
      return;
    }

    setState(() {
      _isGenerating = true;
      _currentAudio = null;
      _isPlaying = false;
    });

    try {
      await _audioPlayer.stop();

      final bytes = await _ttsService.synthesize(
        text: text,
        voice: _selectedVoice!.shortName,
        rate: _rateStr,
        pitch: _pitchStr,
        volume: _volumeStr,
      );

      // Save to temp file for playback & download
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/freelabs_${DateTime.now().millisecondsSinceEpoch}.mp3');
      await file.writeAsBytes(bytes);

      // Save to history
      final historyItem = HistoryItem(
        id: const Uuid().v4(),
        text: text,
        voice: _selectedVoice!.shortName,
        voiceDisplayName: TtsService.getDisplayName(_selectedVoice!),
        locale: _selectedVoice!.locale,
        createdAt: DateTime.now(),
        filePath: file.path,
      );
      await _historyService.addItem(historyItem);

      if (!mounted) return;
      setState(() {
        _currentAudio = bytes;
        _currentFilePath = file.path;
        _isGenerating = false;
      });

      // Auto play
      await _playAudio();
    } catch (e) {
      if (!mounted) return;
      setState(() => _isGenerating = false);
      _showError('Gagal generate: $e');
    }
  }

  Future<void> _playAudio() async {
    if (_currentFilePath == null) return;
    try {
      await _audioPlayer.play(DeviceFileSource(_currentFilePath!));
      setState(() => _isPlaying = true);
    } catch (e) {
      _showError('Gagal memutar audio: $e');
    }
  }

  Future<void> _togglePlay() async {
    if (_currentFilePath == null) return;
    if (_isPlaying) {
      await _audioPlayer.pause();
      setState(() => _isPlaying = false);
    } else {
      await _playAudio();
    }
  }

  Future<void> _download() async {
    if (_currentAudio == null) return;
    try {
      final dir = await getApplicationDocumentsDirectory();
      final name = 'FreeLabs_${DateTime.now().millisecondsSinceEpoch}.mp3';
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(_currentAudio!);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Disimpan: ${file.path}'),
          backgroundColor: AppTheme.success,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      _showError('Gagal menyimpan: $e');
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.danger,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _textController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // App Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 12, 8),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppTheme.primary, AppTheme.accent],
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.graphic_eq_rounded, color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'FreeLabs',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.5,
                        ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const HistoryScreen()),
                      );
                    },
                    icon: const Icon(Icons.history_rounded),
                    tooltip: 'Riwayat',
                  ),
                ],
              ),
            ),

            // Content
            Expanded(
              child: _isLoadingVoices
                  ? const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(color: AppTheme.primary),
                          SizedBox(height: 16),
                          Text('Memuat suara neural...', style: TextStyle(color: AppTheme.textSecondary)),
                        ],
                      ),
                    )
                  : SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Text Input
                          Text(
                            'Teks',
                            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                  color: AppTheme.textSecondary,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            decoration: BoxDecoration(
                              color: AppTheme.surfaceElevated,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: AppTheme.border),
                            ),
                            child: TextField(
                              controller: _textController,
                              maxLines: 6,
                              minLines: 4,
                              style: const TextStyle(fontSize: 15, height: 1.5),
                              decoration: const InputDecoration(
                                hintText: 'Tulis atau tempel teks di sini...\n\nContoh: Halo, ini adalah demo FreeLabs. Suara AI berkualitas tinggi sepenuhnya gratis.',
                                border: InputBorder.none,
                                enabledBorder: InputBorder.none,
                                focusedBorder: InputBorder.none,
                                contentPadding: EdgeInsets.all(16),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // Voice Selector
                          Text(
                            'Suara',
                            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                  color: AppTheme.textSecondary,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          const SizedBox(height: 8),
                          VoiceSelector(
                            voices: _voices,
                            selectedVoice: _selectedVoice,
                            selectedLocale: _selectedLocale,
                            onLocaleChanged: (locale) {
                              setState(() {
                                _selectedLocale = locale;
                                final localeVoices = _ttsService.getVoicesByLocale(locale);
                                _selectedVoice = localeVoices.isNotEmpty ? localeVoices.first : null;
                              });
                            },
                            onVoiceChanged: (voice) {
                              setState(() => _selectedVoice = voice);
                            },
                          ),
                          const SizedBox(height: 24),

                          // Prosody Controls
                          Text(
                            'Pengaturan Suara',
                            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                  color: AppTheme.textSecondary,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          const SizedBox(height: 12),
                          _buildSlider(
                            label: 'Kecepatan',
                            value: _rate,
                            min: -50,
                            max: 50,
                            display: _rateStr,
                            onChanged: (v) => setState(() => _rate = v),
                          ),
                          _buildSlider(
                            label: 'Pitch',
                            value: _pitch,
                            min: -20,
                            max: 20,
                            display: _pitchStr,
                            onChanged: (v) => setState(() => _pitch = v),
                          ),
                          _buildSlider(
                            label: 'Volume',
                            value: _volume,
                            min: -50,
                            max: 50,
                            display: _volumeStr,
                            onChanged: (v) => setState(() => _volume = v),
                          ),
                          const SizedBox(height: 28),

                          // Generate Button
                          SizedBox(
                            width: double.infinity,
                            height: 52,
                            child: ElevatedButton(
                              onPressed: _isGenerating ? null : _generate,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.primary,
                                disabledBackgroundColor: AppTheme.primary.withOpacity(0.5),
                              ),
                              child: _isGenerating
                                  ? const SizedBox(
                                      width: 22,
                                      height: 22,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2.5,
                                        color: Colors.white,
                                      ),
                                    )
                                  : const Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.auto_awesome, size: 20),
                                        SizedBox(width: 10),
                                        Text('Generate Speech'),
                                      ],
                                    ),
                            ),
                          ),

                          // Player controls
                          if (_currentAudio != null) ...[
                            const SizedBox(height: 20),
                            Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: AppTheme.surface,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: AppTheme.border),
                              ),
                              child: Row(
                                children: [
                                  // Play/Pause
                                  Material(
                                    color: AppTheme.primary,
                                    borderRadius: BorderRadius.circular(50),
                                    child: InkWell(
                                      onTap: _togglePlay,
                                      borderRadius: BorderRadius.circular(50),
                                      child: SizedBox(
                                        width: 48,
                                        height: 48,
                                        child: Icon(
                                          _isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                          color: Colors.white,
                                          size: 28,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          _selectedVoice != null
                                              ? TtsService.getDisplayName(_selectedVoice!)
                                              : 'Audio',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          _isPlaying ? 'Sedang diputar...' : 'Siap diputar',
                                          style: const TextStyle(
                                            color: AppTheme.textSecondary,
                                            fontSize: 13,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: _download,
                                    icon: const Icon(Icons.download_rounded),
                                    tooltip: 'Download MP3',
                                    style: IconButton.styleFrom(
                                      backgroundColor: AppTheme.surfaceElevated,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],

                          // Info
                          const SizedBox(height: 32),
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: AppTheme.surface.withOpacity(0.6),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: AppTheme.border.withOpacity(0.5)),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.info_outline_rounded, size: 18, color: AppTheme.textMuted),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    'Menggunakan Microsoft Edge Neural TTS • 300+ suara • Gratis selamanya',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppTheme.textMuted,
                                      height: 1.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSlider({
    required String label,
    required double value,
    required double min,
    required double max,
    required String display,
    required ValueChanged<double> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary),
            ),
          ),
          Expanded(
            child: Slider(
              value: value,
              min: min,
              max: max,
              onChanged: onChanged,
            ),
          ),
          SizedBox(
            width: 56,
            child: Text(
              display,
              textAlign: TextAlign.end,
              style: const TextStyle(
                fontSize: 12,
                color: AppTheme.textMuted,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
