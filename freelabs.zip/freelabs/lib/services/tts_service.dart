import 'dart:typed_data';
import 'package:edge_tts/edge_tts.dart';

class TtsService {
  static final TtsService _instance = TtsService._internal();
  factory TtsService() => _instance;
  TtsService._internal();

  List<Voice> _voices = [];
  bool _isLoadingVoices = false;

  List<Voice> get voices => _voices;
  bool get isLoadingVoices => _isLoadingVoices;

  Future<List<Voice>> loadVoices() async {
    if (_voices.isNotEmpty) return _voices;
    _isLoadingVoices = true;
    try {
      _voices = await listVoices();
      // Sort by locale then name
      _voices.sort((a, b) {
        final localeCompare = a.locale.compareTo(b.locale);
        if (localeCompare != 0) return localeCompare;
        return a.shortName.compareTo(b.shortName);
      });
      return _voices;
    } catch (e) {
      rethrow;
    } finally {
      _isLoadingVoices = false;
    }
  }

  List<String> get availableLocales {
    final locales = _voices.map((v) => v.locale).toSet().toList();
    locales.sort();
    return locales;
  }

  List<Voice> getVoicesByLocale(String locale) {
    return _voices.where((v) => v.locale == locale).toList();
  }

  Future<Uint8List> synthesize({
    required String text,
    required String voice,
    String rate = '+0%',
    String pitch = '+0Hz',
    String volume = '+0%',
  }) async {
    if (text.trim().isEmpty) {
      throw Exception('Teks tidak boleh kosong');
    }

    final communicate = Communicate(
      text: text,
      voice: voice,
      rate: rate,
      pitch: pitch,
      volume: volume,
    );

    return await communicate.toBytes();
  }

  /// Get friendly display name from voice shortName
  static String getDisplayName(Voice voice) {
    // e.g. en-US-AriaNeural -> Aria
    final parts = voice.shortName.split('-');
    if (parts.length >= 3) {
      final name = parts.sublist(2).join('-').replaceAll('Neural', '').replaceAll('Multilingual', '');
      return name.trim().isEmpty ? voice.shortName : name;
    }
    return voice.shortName;
  }

  static String getGenderIcon(String? gender) {
    if (gender == null) return '🗣️';
    final g = gender.toLowerCase();
    if (g.contains('female')) return '👩';
    if (g.contains('male')) return '👨';
    return '🗣️';
  }
}
