import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/history_item.dart';

class HistoryService {
  static const String _key = 'freelabs_history';
  static const int maxItems = 50;

  Future<List<HistoryItem>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw
        .map((e) => HistoryItem.fromJson(jsonDecode(e)))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Future<void> addItem(HistoryItem item) async {
    final prefs = await SharedPreferences.getInstance();
    final list = await getHistory();
    list.insert(0, item);
    // Keep only latest maxItems
    final trimmed = list.take(maxItems).toList();
    await prefs.setStringList(
      _key,
      trimmed.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  Future<void> removeItem(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final list = await getHistory();
    list.removeWhere((e) => e.id == id);
    await prefs.setStringList(
      _key,
      list.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
